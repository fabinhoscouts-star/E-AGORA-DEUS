Pacote de fotografias aprovadas — E AGORA, DEUS?
Seminário Diocesano São José

Conteúdo:
- 51 imagens optimizadas em formato WebP;
- emblema oficial incluído;
- manifest.json com legendas e categorias sugeridas.

Destino previsto no repositório:
assets/seminario/

As fotografias foram extraídas do documento fornecido pela Instituição.
Antes da publicação, confirmar a autorização de divulgação de todas as pessoas
identificáveis, em especial eventuais menores.
